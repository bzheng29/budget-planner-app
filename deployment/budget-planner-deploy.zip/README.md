# AI-Powered Budget Planner with Finn

A smart budget planning web application featuring Finn, an AI assistant powered by Google's Gemini 2.5 Pro model.

## Features

- **Conversational AI Interface**: Chat with Finn to create your personalized budget
- **Advanced AI Reasoning**: Uses Gemini 2.5 Pro for intelligent budget recommendations
- **Contextual Budgeting**: Considers location, family size, life stage, and personal circumstances
- **Dynamic Allocations**: Budget percentages adapt to your specific situation
- **Visual Budget Breakdown**: Clear visualization of spending categories
- **Real-time Recommendations**: Get personalized financial advice

## Setup

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Configure Gemini API**:
   - Get your API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
   - Copy `.env.example` to `.env`:
     ```bash
     cp .env.example .env
     ```
   - Add your API key to `.env`:
     ```
     VITE_GEMINI_API_KEY=your-actual-api-key-here
     ```

3. **Run the application**:
   ```bash
   npm run dev
   ```

## How It Works

### AI-Powered Budget Generation

The app uses Gemini 2.5 Pro to create personalized budgets by:

1. **Gathering Context**: Finn asks about your income, location, family situation, and financial goals
2. **AI Analysis**: Gemini analyzes your profile considering:
   - Cost of living in your area
   - Family-specific needs
   - Life stage priorities
   - Debt obligations
   - Risk tolerance
3. **Dynamic Budgeting**: Creates custom allocations instead of fixed percentages
4. **Reasoning Transparency**: Explains why each allocation was made

### Example AI Reasoning

For a family of 3 in San Francisco with $8,000 monthly income:
- **Housing (35%)**: Increased due to high cost area
- **Food (15%)**: Adjusted for family meals and children
- **Transportation (10%)**: Reduced assuming public transit
- **Healthcare (8%)**: Increased for family coverage

## Technology Stack

- **Frontend**: React + TypeScript + Vite
- **AI Model**: Gemini 2.5 Pro
- **Styling**: Custom CSS with responsive design
- **State Management**: React hooks

## Development

The app gracefully falls back to rule-based budgeting if the Gemini API is unavailable, ensuring users always get budget recommendations.

### Key Components

- `FinnChat`: Main chat interface component
- `AIBudgetReasoningService`: Handles Gemini API integration
- `BudgetVisualization`: Displays budget breakdown
- `aiBudgetCalculator`: Orchestrates AI budget generation

## Deployment

### Quick Deploy to Google Cloud Run

1. **Prerequisites**:
   - Google Cloud account with billing enabled
   - `gcloud` CLI installed
   - Docker installed

2. **Deploy with one command**:
   ```bash
   export GCP_PROJECT_ID=your-project-id
   export GEMINI_API_KEY=your-gemini-api-key
   ./scripts/deploy-to-gcp.sh
   ```

3. **Your app will be live at**: `https://budget-planner-finn-xxxxx.run.app`

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed deployment instructions.

### Deploy with GitHub Actions

1. Add these secrets to your GitHub repository:
   - `GCP_PROJECT_ID`: Your Google Cloud project ID
   - `GCP_SA_KEY`: Service account JSON key
   - `GEMINI_API_KEY`: Your Gemini API key

2. Push to main branch to auto-deploy

## Architecture on GCP

- **Hosting**: Cloud Run (serverless, scales to zero)
- **Container**: Docker with nginx
- **CI/CD**: Cloud Build or GitHub Actions
- **Security**: API keys in Secret Manager
- **Performance**: CDN-ready, gzip compression

## Future Enhancements

- Integration with bank APIs for automatic spending analysis
- Multi-month budget tracking
- Goal progress visualization
- Export budget to spreadsheet
- Mobile app version

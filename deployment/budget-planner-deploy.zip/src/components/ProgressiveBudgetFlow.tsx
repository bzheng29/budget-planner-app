import React, { useState, useEffect } from 'react';
import { ExpenseUpload } from './ExpenseUpload';
import { ExpenseParserService, type ExpenseMetadata } from '../services/expenseParserService';
import { calculateAIBudget } from '../utils/aiBudgetCalculator';
import BudgetResults from './BudgetResults';
import type { UserProfile, Budget } from '../types';
import './ProgressiveBudgetFlow.css';

interface Step {
  id: string;
  title: string;
  description: string;
  component: React.ComponentType<any>;
  isOptional?: boolean;
  condition?: (data: UserProfile) => boolean;
}

interface StepComponentProps {
  onNext: (data: any) => void;
  onBack?: () => void;
  currentData: UserProfile;
  expenseMetadata?: ExpenseMetadata;
}

const ProgressiveBudgetFlow: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [userProfile, setUserProfile] = useState<UserProfile>({});
  const [expenseMetadata, setExpenseMetadata] = useState<ExpenseMetadata | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [dynamicSteps, setDynamicSteps] = useState<Step[]>([]);
  const [finalBudget, setFinalBudget] = useState<Budget | null>(null);
  const [budgetReasoning, setBudgetReasoning] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [completedStepIds, setCompletedStepIds] = useState<Set<string>>(new Set());
  const [totalExpectedSteps, setTotalExpectedSteps] = useState(5); // Base expected steps
  
  const expenseParser = new ExpenseParserService('AIzaSyCZ16kAe0oOUGfiPaZe8C6fjXAdyWbtQk8');

  // Initial steps - will be dynamically adjusted based on user data
  const baseSteps: Step[] = [
    {
      id: 'expense-upload',
      title: 'Upload Expenses',
      description: 'Import your spending data for personalized insights',
      component: ExpenseUploadStep
    },
    {
      id: 'personal-info',
      title: 'Personal Info',
      description: 'Tell us about yourself',
      component: PersonalInfoStep
    },
    {
      id: 'income',
      title: 'Income',
      description: 'Your monthly earnings',
      component: IncomeStep
    },
    {
      id: 'goals',
      title: 'Goals',
      description: 'What are you saving for?',
      component: GoalsStep
    },
    {
      id: 'lifestyle',
      title: 'Lifestyle',
      description: 'Your living situation',
      component: LifestyleStep
    }
  ];

  useEffect(() => {
    // Dynamically adjust steps based on user data
    updateDynamicSteps();
  }, [userProfile, expenseMetadata]);

  const updateDynamicSteps = async () => {
    let steps = [...baseSteps];
    let additionalSteps = 0;
    
    // If user has expense data, we might skip or adjust certain steps
    if (expenseMetadata) {
      // Add debt step only if debt was detected
      if (expenseMetadata.insights.hasDebt || expenseMetadata.missingData.includes('debt information')) {
        steps.splice(4, 0, {
          id: 'debt',
          title: 'Debt',
          description: 'Monthly debt obligations',
          component: DebtStep
        });
        additionalSteps++;
      }
      
      // Add family step if multiple people detected in expenses
      if (expenseMetadata.insights.hasKids || 
          (expenseMetadata.categoryBreakdown['Food & Dining'] && 
           expenseMetadata.categoryBreakdown['Food & Dining'] > expenseMetadata.averageMonthlySpend * 0.3)) {
        steps.splice(3, 0, {
          id: 'family',
          title: 'Family',
          description: 'Household information',
          component: FamilyStep
        });
        additionalSteps++;
      }
    }
    
    setDynamicSteps(steps);
    setTotalExpectedSteps(5 + additionalSteps); // Update total expected steps
  };

  const handleNext = (stepData: any) => {
    const updatedProfile = { ...userProfile, ...stepData };
    setUserProfile(updatedProfile);
    
    // Mark current step as completed
    if (dynamicSteps[currentStep]) {
      setCompletedStepIds(prev => new Set([...prev, dynamicSteps[currentStep].id]));
    }
    
    if (currentStep < dynamicSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Final step - generate budget
      generateBudget(updatedProfile);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFileUpload = async (file: File) => {
    setIsProcessing(true);
    try {
      const { metadata } = await expenseParser.parseExpenseFile(file);
      setExpenseMetadata(metadata);
      
      // Update user profile with expense insights
      const updatedProfile = {
        ...userProfile,
        monthlySpending: metadata.averageMonthlySpend,
        expenseCategories: metadata.categoryBreakdown,
        income: metadata.insights.estimatedIncome,
        location: metadata.insights.location
      };
      setUserProfile(updatedProfile);
      
      // Move to next step
      handleNext({});
    } catch (error) {
      console.error('Error processing file:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const generateBudget = async (profile: UserProfile) => {
    setIsProcessing(true);
    try {
      const { budget, reasoning } = await calculateAIBudget(profile);
      setFinalBudget(budget);
      setBudgetReasoning(reasoning);
      setShowResults(true);
    } catch (error) {
      console.error('Error generating budget:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleEditBudget = () => {
    setShowResults(false);
    setCurrentStep(0);
  };

  // Calculate progress based on completed steps and total expected steps
  const calculateProgress = () => {
    // If we haven't loaded steps yet, show minimal progress
    if (dynamicSteps.length === 0) return 5;
    
    // Calculate based on completed steps + current step progress
    const completedCount = completedStepIds.size;
    const currentStepProgress = 0.5; // Assume current step is half done
    const totalProgress = completedCount + currentStepProgress;
    
    // Use total expected steps for smoother progress
    return Math.min(95, (totalProgress / totalExpectedSteps) * 100);
  };
  
  const progressPercentage = calculateProgress();

  if (dynamicSteps.length === 0) {
    return <div>Loading...</div>;
  }

  if (showResults && finalBudget) {
    return (
      <BudgetResults 
        budget={finalBudget}
        userProfile={userProfile}
        reasoning={budgetReasoning}
        onEdit={handleEditBudget}
      />
    );
  }

  if (isProcessing && currentStep === dynamicSteps.length - 1) {
    return (
      <div className="generating-budget-container">
        <div className="generating-content">
          <div className="generating-icon">🤖</div>
          <h2>Finn is creating your personalized budget...</h2>
          <p>Analyzing your financial data and optimizing allocations</p>
          <div className="generating-spinner"></div>
        </div>
      </div>
    );
  }

  const CurrentStepComponent = dynamicSteps[currentStep].component;

  return (
    <div className="progressive-flow-container">
      <div className="progress-header">
        <h1>Build Your Budget with Finn</h1>
        <div className="progress-bar-container">
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <div className="progress-steps">
            {dynamicSteps.map((step, index) => {
              const isCompleted = completedStepIds.has(step.id);
              const isActive = index === currentStep;
              const isPending = index > currentStep;
              
              return (
                <div 
                  key={step.id}
                  className={`progress-step ${
                    isCompleted ? 'completed' : 
                    isActive ? 'active' : 
                    isPending ? 'pending' : ''
                  }`}
                  style={{
                    opacity: isPending ? 0.5 : 1,
                    transition: 'all 0.3s ease'
                  }}
                >
                  <div className="step-dot" />
                  <span className="step-label">{step.title}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="step-content">
        <div className="step-header">
          <h2>{dynamicSteps[currentStep].title}</h2>
          <p>{dynamicSteps[currentStep].description}</p>
        </div>

        <CurrentStepComponent
          onNext={handleNext}
          onBack={currentStep > 0 ? handleBack : undefined}
          currentData={userProfile}
          expenseMetadata={expenseMetadata}
          onFileUpload={dynamicSteps[currentStep].id === 'expense-upload' ? handleFileUpload : undefined}
          isProcessing={isProcessing}
        />
      </div>
    </div>
  );
};

// Step Components
const ExpenseUploadStep: React.FC<StepComponentProps & { onFileUpload?: (file: File) => void; isProcessing?: boolean }> = 
  ({ onNext, onFileUpload, isProcessing }) => {
  
  if (isProcessing) {
    return (
      <div className="expense-analysis-loading">
        <div className="analysis-animation">
          <div className="scanning-line"></div>
          <div className="data-points">
            <span className="data-point" style={{animationDelay: '0s'}}>📊</span>
            <span className="data-point" style={{animationDelay: '0.2s'}}>💳</span>
            <span className="data-point" style={{animationDelay: '0.4s'}}>🏠</span>
            <span className="data-point" style={{animationDelay: '0.6s'}}>🚗</span>
            <span className="data-point" style={{animationDelay: '0.8s'}}>🍔</span>
          </div>
        </div>
        <h3>Analyzing your spending patterns...</h3>
        <p>Finn is examining your transactions to understand your lifestyle and create a personalized budget</p>
        <div className="analysis-progress">
          <div className="progress-item">
            <span className="progress-icon">✓</span>
            <span>Reading expense file</span>
          </div>
          <div className="progress-item active">
            <span className="progress-icon">⏳</span>
            <span>Categorizing transactions</span>
          </div>
          <div className="progress-item">
            <span className="progress-icon">○</span>
            <span>Extracting spending patterns</span>
          </div>
          <div className="progress-item">
            <span className="progress-icon">○</span>
            <span>Generating insights</span>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="step-expense-upload">
      {onFileUpload && (
        <ExpenseUpload 
          onFileUpload={onFileUpload}
          isProcessing={isProcessing || false}
        />
      )}
      <div className="step-actions">
        <button 
          className="skip-button"
          onClick={() => onNext({})}
        >
          Skip this step
        </button>
      </div>
    </div>
  );
};

const PersonalInfoStep: React.FC<StepComponentProps> = ({ onNext, onBack, currentData, expenseMetadata }) => {
  const [name, setName] = useState(currentData.name || '');
  const [location, setLocation] = useState(currentData.location || expenseMetadata?.insights.location || '');

  const handleSubmit = () => {
    onNext({ name, location });
  };

  // Show personalized greeting if we have expense data
  const hasExpenseData = !!expenseMetadata;

  return (
    <div className="step-form">
      {hasExpenseData && (
        <div className="personalized-intro">
          <p>Great! I've analyzed your expenses and learned a bit about your spending habits. Now let's get to know you better.</p>
        </div>
      )}
      
      <div className="form-group">
        <label>What's your name?</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
          className="form-input"
        />
      </div>

      <div className="form-group">
        <label>Where do you live?</label>
        {expenseMetadata?.insights.location && (
          <div className="detected-info">
            <span className="detected-icon">📍</span>
            <p>Based on your transactions, it looks like you might be in {expenseMetadata.insights.location}</p>
          </div>
        )}
        <input
          type="text"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="City or region"
          className="form-input"
        />
        <p className="form-hint">This helps us adjust for cost of living</p>
      </div>

      <div className="step-actions">
        {onBack && <button className="back-button" onClick={onBack}>Back</button>}
        <button 
          className="next-button"
          onClick={handleSubmit}
          disabled={!name || !location}
        >
          Continue
        </button>
      </div>
    </div>
  );
};

const IncomeStep: React.FC<StepComponentProps> = ({ onNext, onBack, currentData, expenseMetadata }) => {
  const suggestedIncome = expenseMetadata?.insights.estimatedIncome || 0;
  const monthlySpend = expenseMetadata?.averageMonthlySpend || 0;
  
  const [income, setIncome] = useState(currentData.income || suggestedIncome || '');
  const [incomeType, setIncomeType] = useState('after-tax');

  // Generate smart income suggestions based on spending
  const generateIncomeOptions = () => {
    if (!monthlySpend) return [3000, 5000, 7000, 10000];
    
    const base = Math.round(monthlySpend / 100) * 100;
    return [
      Math.round(base * 1.2),
      Math.round(base * 1.5),
      Math.round(base * 1.8),
      Math.round(base * 2.2)
    ];
  };

  const commonIncomes = generateIncomeOptions();

  const handleSubmit = () => {
    onNext({ income: Number(income), incomeType });
  };

  // Calculate current savings rate if income is entered
  const currentSavingsRate = income && monthlySpend 
    ? Math.max(0, Math.round(((Number(income) - monthlySpend) / Number(income)) * 100))
    : null;

  return (
    <div className="step-form">
      <div className="form-group">
        <label>What's your monthly income?</label>
        
        {expenseMetadata && (
          <div className="expense-context">
            <div className="context-item">
              <span className="context-icon">💸</span>
              <div>
                <span className="context-label">Your average spending</span>
                <span className="context-value">${monthlySpend.toLocaleString()}/month</span>
              </div>
            </div>
            {expenseMetadata.insights.lifestyle && (
              <div className="context-item">
                <span className="context-icon">✨</span>
                <div>
                  <span className="context-label">Lifestyle pattern</span>
                  <span className="context-value">{expenseMetadata.insights.lifestyle}</span>
                </div>
              </div>
            )}
          </div>
        )}
        
        {suggestedIncome > 0 && (
          <div className="suggestion-box">
            <span className="suggestion-icon">🎯</span>
            <p>Based on your {expenseMetadata?.insights.lifestyle} spending pattern, we estimate your income around ${suggestedIncome.toLocaleString()}/month</p>
          </div>
        )}

        <input
          type="number"
          value={income}
          onChange={(e) => setIncome(e.target.value)}
          placeholder="Enter monthly income"
          className="form-input large"
        />

        {currentSavingsRate !== null && (
          <div className="live-calculation">
            {currentSavingsRate > 0 ? (
              <p className="positive">This would give you a {currentSavingsRate}% savings rate 🎉</p>
            ) : (
              <p className="warning">⚠️ This income might not cover all your expenses</p>
            )}
          </div>
        )}

        <div className="quick-select">
          {commonIncomes.map(amount => (
            <button
              key={amount}
              className={`amount-button ${income === amount ? 'selected' : ''}`}
              onClick={() => setIncome(amount.toString())}
            >
              ${amount.toLocaleString()}
            </button>
          ))}
        </div>

        <div className="income-type">
          <label>
            <input
              type="radio"
              value="after-tax"
              checked={incomeType === 'after-tax'}
              onChange={(e) => setIncomeType(e.target.value)}
            />
            After tax (take-home)
          </label>
          <label>
            <input
              type="radio"
              value="before-tax"
              checked={incomeType === 'before-tax'}
              onChange={(e) => setIncomeType(e.target.value)}
            />
            Before tax (gross)
          </label>
        </div>
      </div>

      <div className="step-actions">
        {onBack && <button className="back-button" onClick={onBack}>Back</button>}
        <button 
          className="next-button"
          onClick={handleSubmit}
          disabled={!income || Number(income) <= 0}
        >
          Continue
        </button>
      </div>
    </div>
  );
};

const GoalsStep: React.FC<StepComponentProps> = ({ onNext, onBack, currentData, expenseMetadata }) => {
  // Calculate current actual savings rate if we have expense data
  const currentActualSavings = expenseMetadata && currentData.income
    ? Math.max(0, Math.round(((currentData.income - expenseMetadata.averageMonthlySpend) / currentData.income) * 100))
    : null;
  
  const [savingsGoal, setSavingsGoal] = useState(
    currentData.savingsGoal || currentActualSavings || expenseMetadata?.insights.savingsRate || 20
  );
  const [financialGoals, setFinancialGoals] = useState<string[]>(currentData.financialGoals || []);

  // Personalize goal options based on expense insights
  const getPersonalizedGoals = () => {
    const baseGoals = [
      { id: 'emergency', label: 'Build emergency fund', icon: '🛡️', priority: 1 },
      { id: 'house', label: 'Save for a house', icon: '🏠', priority: 2 },
      { id: 'retirement', label: 'Retirement savings', icon: '🏖️', priority: 3 },
      { id: 'debt', label: 'Pay off debt', icon: '💳', priority: expenseMetadata?.insights.hasDebt ? 0 : 4 },
      { id: 'vacation', label: 'Dream vacation', icon: '✈️', priority: 5 },
      { id: 'education', label: 'Education fund', icon: '🎓', priority: expenseMetadata?.insights.hasKids ? 1 : 6 },
      { id: 'car', label: 'New car', icon: '🚗', priority: expenseMetadata?.insights.transportMode === 'car' ? 2 : 7 },
      { id: 'wedding', label: 'Wedding', icon: '💍', priority: 8 }
    ];

    return baseGoals.sort((a, b) => a.priority - b.priority);
  };

  const goalOptions = getPersonalizedGoals();

  const toggleGoal = (goalId: string) => {
    setFinancialGoals(prev => 
      prev.includes(goalId) 
        ? prev.filter(g => g !== goalId)
        : [...prev, goalId]
    );
  };

  const handleSubmit = () => {
    onNext({ savingsGoal, financialGoals });
  };

  // Calculate emergency fund status
  const monthsOfExpenses = expenseMetadata && currentData.income
    ? Math.round((currentData.income * savingsGoal / 100) / expenseMetadata.averageMonthlySpend * 12)
    : null;

  return (
    <div className="step-form">
      <div className="form-group">
        <label>How much would you like to save each month?</label>
        
        {currentActualSavings !== null && (
          <div className="current-savings-info">
            <span className="info-icon">📊</span>
            <p>You're currently saving about {currentActualSavings}% of your income</p>
          </div>
        )}
        
        <div className="savings-benchmarks">
          <h4>📊 储蓄率参考标准</h4>
          <div className="benchmark-grid">
            <div className={`benchmark-item ${savingsGoal <= 10 ? 'active' : ''}`}>
              <div className="benchmark-range">5-10%</div>
              <div className="benchmark-label">刚起步</div>
              <div className="benchmark-desc">适合刚开始工作或有债务的人</div>
            </div>
            <div className={`benchmark-item ${savingsGoal > 10 && savingsGoal <= 20 ? 'active' : ''}`}>
              <div className="benchmark-range">10-20%</div>
              <div className="benchmark-label">标准建议 ✓</div>
              <div className="benchmark-desc">大多数专家建议的储蓄率</div>
            </div>
            <div className={`benchmark-item ${savingsGoal > 20 && savingsGoal <= 30 ? 'active' : ''}`}>
              <div className="benchmark-range">20-30%</div>
              <div className="benchmark-label">积极储蓄</div>
              <div className="benchmark-desc">加速实现财务目标</div>
            </div>
            <div className={`benchmark-item ${savingsGoal > 30 ? 'active' : ''}`}>
              <div className="benchmark-range">30%+</div>
              <div className="benchmark-label">超级储蓄</div>
              <div className="benchmark-desc">快速积累财富，提前退休</div>
            </div>
          </div>
        </div>
        
        <div className="savings-slider-container">
          <input
            type="range"
            min="5"
            max="50"
            value={savingsGoal}
            onChange={(e) => setSavingsGoal(Number(e.target.value))}
            className="savings-slider"
          />
          <div className="savings-display">
            <span className="savings-percentage">{savingsGoal}%</span>
            <span className="savings-amount">
              ¥{currentData.income ? Math.round(currentData.income * savingsGoal / 100).toLocaleString() : '---'}/月
            </span>
          </div>
        </div>
        
        <div className="savings-context">
          {savingsGoal < 10 && (
            <div className="context-message low">
              <span className="icon">💡</span>
              <p>虽然储蓄率较低，但建立储蓄习惯是很好的开始！随着收入增长，可以逐步提高。</p>
            </div>
          )}
          {savingsGoal >= 10 && savingsGoal <= 20 && (
            <div className="context-message good">
              <span className="icon">✅</span>
              <p>很棒！{savingsGoal}% 是一个健康的储蓄率。这可以帮您建立紧急储备金并实现长期目标。</p>
            </div>
          )}
          {savingsGoal > 20 && savingsGoal <= 30 && (
            <div className="context-message great">
              <span className="icon">🎆</span>
              <p>太好了！{savingsGoal}% 的储蓄率将帮您更快地实现财务自由。记得保持生活平衡哦！</p>
            </div>
          )}
          {savingsGoal > 30 && (
            <div className="context-message excellent">
              <span className="icon">🚀</span>
              <p>令人印象深刻！{savingsGoal}% 的储蓄率非常高。确保这个目标是可持续的，不要牺牲生活质量。</p>
            </div>
          )}
        </div>
        
        {monthsOfExpenses !== null && (
          <div className="savings-insight">
            <p>At this rate, you'll save {monthsOfExpenses} months of expenses per year</p>
          </div>
        )}
      </div>

      <div className="form-group">
        <label>What are your financial goals?</label>
        
        {expenseMetadata?.insights.hasDebt && (
          <div className="goal-suggestion">
            <span className="suggestion-icon">💡</span>
            <p>We noticed you have debt payments. Consider prioritizing debt payoff for financial freedom!</p>
          </div>
        )}
        
        <div className="goals-grid">
          {goalOptions.map(goal => (
            <button
              key={goal.id}
              className={`goal-option ${financialGoals.includes(goal.id) ? 'selected' : ''}`}
              onClick={() => toggleGoal(goal.id)}
            >
              <span className="goal-icon">{goal.icon}</span>
              <span className="goal-label">{goal.label}</span>
              {goal.priority === 0 && <span className="recommended-badge">Recommended</span>}
            </button>
          ))}
        </div>
      </div>

      <div className="step-actions">
        {onBack && <button className="back-button" onClick={onBack}>Back</button>}
        <button 
          className="next-button"
          onClick={handleSubmit}
        >
          Continue
        </button>
      </div>
    </div>
  );
};

const LifestyleStep: React.FC<StepComponentProps> = ({ onNext, onBack, currentData }) => {
  const [lifeStage, setLifeStage] = useState(currentData.lifeStage || '');
  const [riskTolerance, setRiskTolerance] = useState(currentData.preferences?.riskTolerance || 'moderate');

  const lifeStageOptions = [
    { id: 'student', label: 'Student', icon: '🎓' },
    { id: 'early-career', label: 'Early Career', icon: '💼' },
    { id: 'mid-career', label: 'Mid Career', icon: '📈' },
    { id: 'family', label: 'Growing Family', icon: '👨‍👩‍👧‍👦' },
    { id: 'pre-retirement', label: 'Pre-Retirement', icon: '🌅' },
    { id: 'retired', label: 'Retired', icon: '🏖️' }
  ];

  const handleSubmit = () => {
    onNext({ 
      lifeStage,
      preferences: { ...currentData.preferences, riskTolerance }
    });
  };

  return (
    <div className="step-form">
      <div className="form-group">
        <label>Which best describes your life stage?</label>
        <div className="life-stage-grid">
          {lifeStageOptions.map(stage => (
            <button
              key={stage.id}
              className={`life-stage-option ${lifeStage === stage.id ? 'selected' : ''}`}
              onClick={() => setLifeStage(stage.id)}
            >
              <span className="stage-icon">{stage.icon}</span>
              <span className="stage-label">{stage.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="form-group">
        <label>What's your financial risk tolerance?</label>
        <div className="risk-options">
          <button
            className={`risk-option ${riskTolerance === 'conservative' ? 'selected' : ''}`}
            onClick={() => setRiskTolerance('conservative')}
          >
            <span className="risk-icon">🛡️</span>
            <span className="risk-label">Conservative</span>
            <span className="risk-desc">Prefer stability and security</span>
          </button>
          <button
            className={`risk-option ${riskTolerance === 'moderate' ? 'selected' : ''}`}
            onClick={() => setRiskTolerance('moderate')}
          >
            <span className="risk-icon">⚖️</span>
            <span className="risk-label">Moderate</span>
            <span className="risk-desc">Balance growth and security</span>
          </button>
          <button
            className={`risk-option ${riskTolerance === 'aggressive' ? 'selected' : ''}`}
            onClick={() => setRiskTolerance('aggressive')}
          >
            <span className="risk-icon">🚀</span>
            <span className="risk-label">Aggressive</span>
            <span className="risk-desc">Focus on growth potential</span>
          </button>
        </div>
      </div>

      <div className="step-actions">
        {onBack && <button className="back-button" onClick={onBack}>Back</button>}
        <button 
          className="next-button"
          onClick={handleSubmit}
          disabled={!lifeStage}
        >
          Create My Budget
        </button>
      </div>
    </div>
  );
};

const FamilyStep: React.FC<StepComponentProps> = ({ onNext, onBack, currentData }) => {
  const [familySize, setFamilySize] = useState(currentData.familySize || 1);
  const [hasKids, setHasKids] = useState(false);

  const handleSubmit = () => {
    onNext({ familySize, hasKids });
  };

  return (
    <div className="step-form">
      <div className="form-group">
        <label>How many people are in your household?</label>
        <div className="family-size-selector">
          {[1, 2, 3, 4, 5].map(size => (
            <button
              key={size}
              className={`size-option ${familySize === size ? 'selected' : ''}`}
              onClick={() => setFamilySize(size)}
            >
              {size}{size > 4 && '+'}
            </button>
          ))}
        </div>
      </div>

      {familySize > 1 && (
        <div className="form-group">
          <label>Do you have children?</label>
          <div className="yes-no-options">
            <button
              className={`option-button ${hasKids ? 'selected' : ''}`}
              onClick={() => setHasKids(true)}
            >
              Yes
            </button>
            <button
              className={`option-button ${!hasKids ? 'selected' : ''}`}
              onClick={() => setHasKids(false)}
            >
              No
            </button>
          </div>
        </div>
      )}

      <div className="step-actions">
        {onBack && <button className="back-button" onClick={onBack}>Back</button>}
        <button className="next-button" onClick={handleSubmit}>Continue</button>
      </div>
    </div>
  );
};

const DebtStep: React.FC<StepComponentProps> = ({ onNext, onBack, currentData }) => {
  const [debtAmount, setDebtAmount] = useState(currentData.debtObligations || 0);
  const [debtTypes, setDebtTypes] = useState<string[]>([]);

  const debtOptions = [
    { id: 'credit-card', label: 'Credit Cards' },
    { id: 'student-loan', label: 'Student Loans' },
    { id: 'car-loan', label: 'Car Loan' },
    { id: 'mortgage', label: 'Mortgage' },
    { id: 'personal', label: 'Personal Loan' }
  ];

  const toggleDebtType = (debtId: string) => {
    setDebtTypes(prev => 
      prev.includes(debtId) 
        ? prev.filter(d => d !== debtId)
        : [...prev, debtId]
    );
  };

  const handleSubmit = () => {
    onNext({ debtObligations: debtAmount, debtTypes });
  };

  return (
    <div className="step-form">
      <div className="form-group">
        <label>Total monthly debt payments</label>
        <input
          type="number"
          value={debtAmount}
          onChange={(e) => setDebtAmount(Number(e.target.value))}
          placeholder="$0"
          className="form-input large"
        />
      </div>

      <div className="form-group">
        <label>What types of debt do you have?</label>
        <div className="debt-types">
          {debtOptions.map(debt => (
            <button
              key={debt.id}
              className={`debt-option ${debtTypes.includes(debt.id) ? 'selected' : ''}`}
              onClick={() => toggleDebtType(debt.id)}
            >
              {debt.label}
            </button>
          ))}
        </div>
      </div>

      <div className="step-actions">
        {onBack && <button className="back-button" onClick={onBack}>Back</button>}
        <button className="next-button" onClick={handleSubmit}>Continue</button>
      </div>
    </div>
  );
};

export default ProgressiveBudgetFlow;
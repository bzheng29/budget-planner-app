import './App.css'
import ProgressiveBudgetFlow from './components/ProgressiveBudgetFlow'

function App() {
  return (
    <div className="app">
      <ProgressiveBudgetFlow />
    </div>
  )
}

export default App

import './App.css'
import FinnChat from './components/FinnChat'

function App() {
  return (
    <div className="app">
      <FinnChat />
    </div>
  )
}

export default App

import type { UserProfile, Budget, BudgetCategory, SpendingData } from '../types'

export function calculateBudget(profile: UserProfile, spendingData?: SpendingData[]): Budget {
  const income = profile.income || 0
  const savingsGoal = profile.savingsGoal || income * 0.2
  const essentialExpenses = profile.essentialExpenses || income * 0.5
  
  const categories: BudgetCategory[] = [
    {
      name: 'Housing',
      amount: income * 0.28,
      percentage: 28,
      isEssential: true,
      description: 'Rent/mortgage, utilities, insurance'
    },
    {
      name: 'Food & Groceries',
      amount: income * 0.12,
      percentage: 12,
      isEssential: true,
      description: 'Groceries and essential meals'
    },
    {
      name: 'Transportation',
      amount: income * 0.15,
      percentage: 15,
      isEssential: true,
      description: 'Car payments, gas, public transit'
    },
    {
      name: 'Healthcare',
      amount: income * 0.05,
      percentage: 5,
      isEssential: true,
      description: 'Insurance, medications, checkups'
    },
    {
      name: 'Personal & Lifestyle',
      amount: income * 0.10,
      percentage: 10,
      isEssential: false,
      description: 'Clothing, personal care, hobbies'
    },
    {
      name: 'Entertainment',
      amount: income * 0.05,
      percentage: 5,
      isEssential: false,
      description: 'Dining out, movies, subscriptions'
    },
    {
      name: 'Miscellaneous',
      amount: income * 0.05,
      percentage: 5,
      isEssential: false,
      description: 'Unexpected expenses, gifts'
    }
  ]
  
  const totalExpenses = categories.reduce((sum, cat) => sum + cat.amount, 0)
  const savings = income - totalExpenses
  const savingsRate = income > 0 ? (savings / income) * 100 : 0
  
  return {
    income,
    categories,
    totalExpenses,
    savings,
    savingsRate
  }
}

export function analyzeBudgetHealth(budget: Budget): {
  score: number
  recommendations: string[]
} {
  const recommendations: string[] = []
  let score = 100
  
  if (budget.savingsRate < 10) {
    score -= 20
    recommendations.push("Your savings rate is below 10%. Consider reducing discretionary spending.")
  } else if (budget.savingsRate < 20) {
    score -= 10
    recommendations.push("Aim to increase your savings rate to 20% for better financial security.")
  }
  
  const housingPercentage = (budget.categories.find(c => c.name === 'Housing')?.amount || 0) / budget.income * 100
  if (housingPercentage > 30) {
    score -= 15
    recommendations.push("Housing costs exceed 30% of income. Consider more affordable options.")
  }
  
  const essentialTotal = budget.categories
    .filter(c => c.isEssential)
    .reduce((sum, cat) => sum + cat.amount, 0)
  const essentialPercentage = essentialTotal / budget.income * 100
  
  if (essentialPercentage > 70) {
    score -= 15
    recommendations.push("Essential expenses are too high. Look for ways to reduce fixed costs.")
  }
  
  if (recommendations.length === 0) {
    recommendations.push("Great job! Your budget is well-balanced.")
  }
  
  return { score, recommendations }
}